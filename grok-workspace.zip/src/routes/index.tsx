import { useEffect, useRef, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { Anchor, Boxes, Waves } from "lucide-react";
import { previewPathPrefix } from "@/lib/preview-path-prefix";

export const Route = createFileRoute("/")({ component: Home });

declare global {
  interface Window {
    __controlsTest?: {
      getYaw: () => number;
      getSpeed: () => number;
      setKeys: (codes: string[]) => void;
    };
  }
}

type Boot = "loading" | "ready" | "error";

function tideSrc(qa: boolean) {
  const prefix = previewPathPrefix(window.location.hostname, window.location.pathname) ?? "";
  return `${prefix}/tide/index.html${qa ? "?qa=1" : ""}`;
}

function Home() {
  const [entered, setEntered] = useState(false);
  const [src, setSrc] = useState<string | null>(null);
  const [boot, setBoot] = useState<Boot>("loading");
  const [attempt, setAttempt] = useState(0);
  const frameRef = useRef<HTMLIFrameElement>(null);

  useEffect(() => {
    const qa = new URLSearchParams(window.location.search).get("qa") === "1";
    if (qa) setEntered(true);
  }, []);

  useEffect(() => {
    if (!entered) return;
    const qa = new URLSearchParams(window.location.search).get("qa") === "1";
    setBoot("loading");
    setSrc(tideSrc(qa));
  }, [entered, attempt]);

  useEffect(() => {
    if (!entered) return;
    const timer = window.setTimeout(() => {
      setBoot((current) => (current === "ready" ? current : "error"));
    }, 45000);
    return () => window.clearTimeout(timer);
  }, [entered, attempt]);

  useEffect(() => {
    const onMessage = (event: MessageEvent) => {
      const data = event.data as { type?: string } | null;
      if (data && data.type === "tide-ready") setBoot("ready");
    };
    window.addEventListener("message", onMessage);
    return () => window.removeEventListener("message", onMessage);
  }, []);

  useEffect(() => {
    if (!entered || !src) return;
    const id = window.setInterval(() => {
      const child = frameRef.current?.contentWindow as
        | (Window & { __tidePlay?: boolean; __controlsTest?: Window["__controlsTest"] })
        | null;
      if (!child) return;
      try {
        child.__tidePlay = true;
        if (child.__controlsTest) window.__controlsTest = child.__controlsTest;
        const canvas = frameRef.current?.contentDocument?.querySelector("canvas");
        if (canvas instanceof HTMLCanvasElement && document.activeElement !== frameRef.current) {
          canvas.tabIndex = 0;
        }
      } catch {
        /* export still booting */
      }
    }, 200);
    return () => window.clearInterval(id);
  }, [entered, src]);

  useEffect(() => {
    if (!entered) return;
    const forward = (type: "keydown" | "keyup") => (event: KeyboardEvent) => {
      const target = event.target as HTMLElement | null;
      if (target && (target.tagName === "INPUT" || target.tagName === "TEXTAREA")) return;
      const canvas = frameRef.current?.contentDocument?.querySelector("canvas");
      if (!canvas) return;
      if (document.activeElement === frameRef.current) return;
      canvas.dispatchEvent(
        new KeyboardEvent(type, {
          key: event.key,
          code: event.code,
          bubbles: true,
          cancelable: true,
          repeat: event.repeat,
          shiftKey: event.shiftKey,
          ctrlKey: event.ctrlKey,
          altKey: event.altKey,
          metaKey: event.metaKey,
        }),
      );
    };
    const down = forward("keydown");
    const up = forward("keyup");
    window.addEventListener("keydown", down);
    window.addEventListener("keyup", up);
    return () => {
      window.removeEventListener("keydown", down);
      window.removeEventListener("keyup", up);
    };
  }, [entered]);

  if (entered) {
    return (
      <main className="fixed inset-0 overflow-hidden bg-bg text-fg">
        {boot !== "ready" ? (
          <div className="absolute inset-0 z-10 flex flex-col items-center justify-center gap-4 px-6 text-center">
            <p className="font-display text-4xl text-fg">ПРИЛИВ</p>
            <p className="max-w-sm text-base text-muted">
              {boot === "error"
                ? "Верфь не открылась. Проверь сеть и попробуй ещё раз."
                : "Собираем остров, крабов и первую волну…"}
            </p>
            {boot === "error" ? (
              <button
                type="button"
                className="min-h-12 rounded-card bg-primary px-6 font-bold text-primary-ink"
                onClick={() => setAttempt((value) => value + 1)}
              >
                Повторить
              </button>
            ) : null}
          </div>
        ) : null}
        {src ? (
          <iframe
            ref={frameRef}
            title="ПРИЛИВ"
            src={src}
            className="h-full w-full border-0 bg-bg"
            allow="autoplay; fullscreen; pointer-lock; gamepad"
            onLoad={() => {
              frameRef.current?.contentWindow?.focus();
            }}
          />
        ) : null}
      </main>
    );
  }

  return (
    <main className="relative min-h-dvh overflow-hidden bg-bg text-fg">
      <div className="tide-shift absolute inset-x-0 bottom-0 h-2/5 bg-kelp" />
      <div className="absolute inset-x-0 bottom-2/5 h-px bg-brass" />
      <div className="relative mx-auto flex min-h-dvh w-full max-w-3xl flex-col justify-between gap-8 px-5 py-8 sm:px-8">
        <header className="flex flex-col gap-4">
          <p className="text-sm font-bold tracking-wide text-brass">3D · GODOT · ФИЗИКА</p>
          <h1 className="font-display text-5xl text-fg sm:text-7xl">ПРИЛИВ</h1>
          <p className="max-w-xl text-lg leading-relaxed text-muted">
            Островная верфь. Хватай балки и крабов, клей пушки ко льду и переживи волну, которая приходит сама.
          </p>
        </header>
        <ul className="grid gap-3 sm:grid-cols-3">
          <li className="flex flex-col gap-2 rounded-card bg-surface p-4">
            <Anchor className="text-brass" aria-hidden="true" />
            <p className="font-bold text-fg">Хват</p>
            <p className="text-sm leading-relaxed text-muted">Тащи что угодно и бросай. Трамплин подкинет и тебя.</p>
          </li>
          <li className="flex flex-col gap-2 rounded-card bg-surface p-4">
            <Boxes className="text-primary" aria-hidden="true" />
            <p className="font-bold text-fg">Верфь</p>
            <p className="text-sm leading-relaxed text-muted">Ящики, лёд, бомбы, шар-лифт и чертежи одной кнопкой.</p>
          </li>
          <li className="flex flex-col gap-2 rounded-card bg-surface p-4">
            <Waves className="text-brass" aria-hidden="true" />
            <p className="font-bold text-fg">Испытания</p>
            <p className="text-sm leading-relaxed text-muted">Кольцо, башня, крабы против прилива, бутылки.</p>
          </li>
        </ul>
        <div className="flex flex-col gap-3">
          <button
            type="button"
            className="min-h-12 w-full rounded-card bg-primary px-6 py-3 font-display text-lg text-primary-ink sm:w-auto"
            onClick={() => setEntered(true)}
          >
            Выйти на берег
          </button>
          <p className="text-sm leading-relaxed text-muted">
            ПКМ — взгляд, WASD — шаг, ЛКМ — хват. На телефоне стик слева и кнопки справа. Помощь внутри — испытания и сохранение.
          </p>
        </div>
      </div>
    </main>
  );
}
