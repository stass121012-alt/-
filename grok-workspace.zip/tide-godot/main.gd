extends Node3D

const TOOLS := [
	["crate", "Ящик"],
	["ball", "Шар"],
	["plank", "Балка"],
	["spring", "Прыжок"],
	["bomb", "Бомба"],
	["balloon", "Лифт"],
	["block", "Упор"],
	["cannon", "Пушка"],
	["ice", "Лёд"],
	["crab", "Краб"],
]

var player: TidePlayer
var noise := FastNoiseLite.new()
var water: MeshInstance3D
var shark: Node3D
var shark_a := 0.0
var joints: Node3D
var ghost: MeshInstance3D
var tool_i := 0
var place_extra := 0.0
var grid_on := true
var mode := "free"
var playing := false
var won := false
var stable := 0.0
var warmup := 0.0
var tide_phase := 0.15
var tide_active := false
var tide_note := "Отлив"
var water_y := 0.42
var bp := 0
var ui_blockers: Array[Control] = []
var slots: Array[Button] = []
var hotbar: GridContainer
var obj_label: Label
var status_label: Label
var hint_label: Label
var tide_bar: ProgressBar
var tide_label: Label
var help_root: Control
var touch_root: Control
var joy: Control
var joy_knob: Control
var win_label: Label
var speakers: Array[AudioStreamPlayer] = []
var noises := {}
var win_left := 0.0

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	_install_js()
	_audio()
	_lights()
	_island()
	_water_mesh()
	_dress()
	joints = Node3D.new()
	joints.name = "Joints"
	add_child(joints)
	_player()
	_ui()
	await get_tree().physics_frame
	await get_tree().physics_frame
	respawn_player()
	set_mode("free")
	playing = false
	get_tree().paused = true
	_mark_ready()

func _process(dt: float) -> void:
	if shark:
		shark_a += dt * 0.22
		var r := 54.0
		shark.position = Vector3(cos(shark_a) * r, water_y + 0.15, sin(shark_a) * r)
		shark.rotation.y = -shark_a + PI * 0.5
	_poll_play()
	if playing:
		_ghost()
	if win_left > 0.0:
		win_left -= dt
		if win_left <= 0.0 and win_label:
			win_label.visible = false

func _physics_process(dt: float) -> void:
	if not playing:
		return
	dt = minf(dt, 0.05)
	warmup += dt
	_tide(dt)
	_buoy()
	_goals(dt)

func _install_js() -> void:
	if not OS.has_feature("web"):
		return
	JavaScriptBridge.eval("(function(){if(window.__tideHook)return;window.__tideHook=1;window.addEventListener('message',function(e){if(e.data&&e.data.type==='tide-play')window.__tidePlay=true;});})();", true)

func _mark_ready() -> void:
	if not OS.has_feature("web"):
		return
	JavaScriptBridge.eval("(function(){window.__controlsTest={getYaw:function(){return window.__godotYaw||0;},getSpeed:function(){return window.__godotSpeed||0;},setKeys:function(codes){window.__godotKeys=codes||[];}};window.__tideReady=true;try{parent.postMessage({type:'tide-ready'},'*');}catch(e){}})();", true)

func _poll_play() -> void:
	if playing:
		return
	var go := false
	if OS.has_feature("web"):
		var v = JavaScriptBridge.eval("(window.__tidePlay===true)||(String(location.search).indexOf('qa=1')>=0)", true)
		go = v == true or v == 1
	elif OS.get_environment("TIDE_QA") == "1":
		go = true
	if go:
		playing = true
		get_tree().paused = false

func _audio() -> void:
	noises["pop"] = _wav(520.0, 0.07, 0.25)
	noises["place"] = _wav(340.0, 0.05, 0.22)
	noises["boom"] = _wav(78.0, 0.32, 0.55)
	noises["win"] = _wav(690.0, 0.2, 0.3)
	for _i in 4:
		var p := AudioStreamPlayer.new()
		p.volume_db = -6.0
		p.process_mode = Node.PROCESS_MODE_ALWAYS
		add_child(p)
		speakers.append(p)

func _wav(freq: float, dur: float, volume: float) -> AudioStreamWAV:
	var rate := 22050
	var count := int(rate * dur)
	var data := PackedByteArray()
	data.resize(count * 2)
	for i in count:
		var t := float(i) / float(rate)
		var env := 1.0 - float(i) / float(count)
		var s := sin(TAU * freq * t) * env * volume
		data.encode_s16(i * 2, int(clampf(s, -1.0, 1.0) * 32767.0))
	var stream := AudioStreamWAV.new()
	stream.format = AudioStreamWAV.FORMAT_16_BITS
	stream.mix_rate = rate
	stream.stereo = false
	stream.data = data
	return stream

func play_sfx(n: String) -> void:
	if not noises.has(n):
		return
	for p in speakers:
		if not p.playing:
			p.stream = noises[n]
			p.play()
			return

func _lights() -> void:
	var env := Environment.new()
	env.background_mode = Environment.BG_SKY
	var sky := Sky.new()
	var mat := ProceduralSkyMaterial.new()
	mat.sky_top_color = Color("163844")
	mat.sky_horizon_color = Color("f0b27a")
	mat.sky_curve = 0.14
	mat.ground_bottom_color = Color("10262e")
	mat.ground_horizon_color = Color("c98455")
	mat.sun_angle_max = 30.0
	sky.sky_material = mat
	env.sky = sky
	env.ambient_light_source = Environment.AMBIENT_SOURCE_SKY
	env.ambient_light_energy = 0.92
	env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	env.tonemap_exposure = 1.05
	env.fog_enabled = true
	env.fog_density = 0.0042
	env.fog_light_color = Color("d7c6b2")
	env.fog_aerial_perspective = 0.35
	var we := WorldEnvironment.new()
	we.environment = env
	add_child(we)
	var sun := DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-36, 42, 0)
	sun.light_color = Color("ffd2a8")
	sun.light_energy = 1.5
	sun.shadow_enabled = true
	sun.shadow_bias = 0.06
	sun.directional_shadow_max_distance = 80.0
	add_child(sun)
	var fill := DirectionalLight3D.new()
	fill.rotation_degrees = Vector3(-18, -140, 0)
	fill.light_color = Color("9fd0d4")
	fill.light_energy = 0.38
	add_child(fill)

func terrain_height(x: float, z: float) -> float:
	var d := Vector2(x, z).length()
	var mask := smoothstep(46.0, 22.0, d)
	var n := noise.get_noise_2d(x, z)
	var h := mask * (3.1 + n * 2.8)
	var yard := Vector2(x - 1.5, z - 1.0).length()
	if yard < 14.0:
		h = lerpf(h, 2.35, smoothstep(14.0, 5.5, yard))
	var rng := Vector2(x + 15.0, z - 11.0).length()
	if rng < 8.0:
		h = lerpf(h, 3.15, smoothstep(8.0, 3.0, rng))
	if d > 30.0:
		h *= smoothstep(47.0, 30.0, d)
	return h

func _island() -> void:
	noise.seed = 11
	noise.frequency = 0.055
	noise.fractal_octaves = 3
	var st := SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)
	var n := 64
	var span := 100.0
	var step := span / float(n)
	var origin := -span * 0.5
	var heights := []
	for z in n + 1:
		var row := []
		for x in n + 1:
			row.append(terrain_height(origin + float(x) * step, origin + float(z) * step))
		heights.append(row)
	for z in n:
		for x in n:
			var x0 := origin + float(x) * step
			var z0 := origin + float(z) * step
			var p00 := Vector3(x0, heights[z][x], z0)
			var p10 := Vector3(x0 + step, heights[z][x + 1], z0)
			var p01 := Vector3(x0, heights[z + 1][x], z0 + step)
			var p11 := Vector3(x0 + step, heights[z + 1][x + 1], z0 + step)
			_tri(st, p00, p01, p10)
			_tri(st, p10, p01, p11)
	st.generate_normals()
	var mesh := st.commit()
	var mi := MeshInstance3D.new()
	mi.mesh = mesh
	var mat := StandardMaterial3D.new()
	mat.vertex_color_use_as_albedo = true
	mat.roughness = 0.92
	mi.material_override = mat
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_ON
	var body := StaticBody3D.new()
	body.collision_layer = 1
	body.collision_mask = 1
	var col := CollisionShape3D.new()
	col.shape = mesh.create_trimesh_shape()
	body.add_child(col)
	body.add_child(mi)
	add_child(body)

func _tri(st: SurfaceTool, a: Vector3, b: Vector3, c: Vector3) -> void:
	for p in [a, b, c]:
		st.set_color(_tint(p))
		st.add_vertex(p)

func _tint(p: Vector3) -> Color:
	var d := Vector2(p.x, p.z).length()
	if p.y < 0.65:
		return Color("cbb488").lerp(Color("1a4c54"), clampf(0.7 - p.y, 0.0, 1.0))
	if p.y < 2.15:
		return Color("e0c79a")
	if d < 16.0 and p.y < 3.3:
		return Color("c4a46a")
	if p.y < 4.4:
		return Color("3e7a4c")
	return Color("8d8478")

func _water_mesh() -> void:
	water = MeshInstance3D.new()
	var plane := PlaneMesh.new()
	plane.size = Vector2(240, 240)
	plane.subdivide_width = 48
	plane.subdivide_depth = 48
	water.mesh = plane
	var sh := Shader.new()
	sh.code = "shader_type spatial; render_mode blend_mix, depth_draw_opaque, cull_disabled, specular_schlick_ggx; uniform vec4 albedo_color: source_color = vec4(0.06, 0.32, 0.38, 0.88); void vertex(){ VERTEX.y += sin(VERTEX.x * 0.16 + TIME * 1.25) * 0.12 + cos(VERTEX.z * 0.13 + TIME * 0.85) * 0.09; } void fragment(){ ALBEDO = albedo_color.rgb; ALPHA = albedo_color.a; ROUGHNESS = 0.12; METALLIC = 0.22; SPECULAR = 0.55; }"
	var mat := ShaderMaterial.new()
	mat.shader = sh
	water.material_override = mat
	water.position.y = water_y
	water.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(water)

func _dress() -> void:
	for i in 14:
		var ang := float(i) / 14.0 * TAU + 0.4
		var rad := 10.0 + float(i % 5) * 3.4
		var x := cos(ang) * rad
		var z := sin(ang) * rad
		var h := terrain_height(x, z)
		if h < 2.2 or h > 5.5:
			continue
		if Vector2(x - 1.5, z - 1.0).length() < 7.0:
			continue
		if Vector2(x + 15.0, z - 11.0).length() < 6.0:
			continue
		_tree(Vector3(x, h, z), 0.85 + float(i % 3) * 0.18)
	_platform(Vector3(-15.0, 0, 11.0), Vector3(7.2, 0.35, 5.2), Color("6b4a30"))
	_ring(Vector3(16.5, 0.0, 8.0))
	_dock()
	shark = Node3D.new()
	var fin := MeshInstance3D.new()
	var cone := CylinderMesh.new()
	cone.top_radius = 0.01
	cone.bottom_radius = 0.28
	cone.height = 0.7
	fin.mesh = cone
	fin.rotation_degrees = Vector3(0, 0, 18)
	var fm := StandardMaterial3D.new()
	fm.albedo_color = Color("16343c")
	fm.roughness = 0.4
	fin.material_override = fm
	shark.add_child(fin)
	add_child(shark)

func _tree(at: Vector3, scale: float) -> void:
	var root := StaticBody3D.new()
	root.collision_layer = 1
	root.collision_mask = 1
	root.position = at
	var trunk := MeshInstance3D.new()
	var cm := CylinderMesh.new()
	cm.top_radius = 0.12 * scale
	cm.bottom_radius = 0.18 * scale
	cm.height = 1.3 * scale
	trunk.mesh = cm
	trunk.position.y = 0.65 * scale
	var tm := StandardMaterial3D.new()
	tm.albedo_color = Color("6a4630")
	tm.roughness = 0.9
	trunk.material_override = tm
	root.add_child(trunk)
	var col := CollisionShape3D.new()
	var cap := CapsuleShape3D.new()
	cap.radius = 0.18 * scale
	cap.height = 1.3 * scale
	col.shape = cap
	col.position.y = 0.65 * scale
	root.add_child(col)
	for k in 3:
		var leaf := MeshInstance3D.new()
		var cone2 := CylinderMesh.new()
		cone2.top_radius = 0.02
		cone2.bottom_radius = (0.85 - float(k) * 0.18) * scale
		cone2.height = 0.85 * scale
		leaf.mesh = cone2
		leaf.position.y = (1.35 + float(k) * 0.48) * scale
		var lm := StandardMaterial3D.new()
		lm.albedo_color = Color("1e6e58").lerp(Color("2f8a62"), float(k) * 0.25)
		lm.roughness = 0.8
		leaf.material_override = lm
		root.add_child(leaf)
	add_child(root)

func _platform(center_xz: Vector3, size: Vector3, color: Color) -> void:
	var h := terrain_height(center_xz.x, center_xz.z)
	var body := StaticBody3D.new()
	body.collision_layer = 1
	body.collision_mask = 1
	body.position = Vector3(center_xz.x, h + size.y * 0.5, center_xz.z)
	var mesh := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = size
	mesh.mesh = bm
	var m := StandardMaterial3D.new()
	m.albedo_color = color
	m.roughness = 0.84
	mesh.material_override = m
	body.add_child(mesh)
	var col := CollisionShape3D.new()
	var shape := BoxShape3D.new()
	shape.size = size
	col.shape = shape
	body.add_child(col)
	add_child(body)

func _ring(xz: Vector3) -> void:
	var h := terrain_height(xz.x, xz.z)
	var pivot := Node3D.new()
	pivot.position = Vector3(xz.x, h + 2.4, xz.z)
	var mi := MeshInstance3D.new()
	var torus := TorusMesh.new()
	torus.inner_radius = 1.05
	torus.outer_radius = 1.38
	mi.mesh = torus
	mi.rotation_degrees = Vector3(90, 0, 0)
	var m := StandardMaterial3D.new()
	m.albedo_color = Color("e2b15a")
	m.metallic = 0.72
	m.roughness = 0.28
	m.emission_enabled = true
	m.emission = Color("e2b15a")
	m.emission_energy_multiplier = 0.25
	mi.material_override = m
	pivot.add_child(mi)
	var area := Area3D.new()
	area.collision_layer = 0
	area.collision_mask = 2
	area.monitorable = false
	var col := CollisionShape3D.new()
	var box := BoxShape3D.new()
	box.size = Vector3(1.3, 1.3, 0.7)
	col.shape = box
	area.add_child(col)
	area.body_entered.connect(_on_ring)
	pivot.add_child(area)
	add_child(pivot)

func _dock() -> void:
	for i in 5:
		_platform(Vector3(2.0, 0, 8.0 + float(i) * 1.7), Vector3(2.2, 0.22, 1.55), Color("8d5a32"))

func _on_ring(body: Node) -> void:
	if mode != "ring" or won:
		return
	if body is RigidBody3D and bool(body.get_meta("goal", false)):
		win("Шар прошёл сквозь кольцо.")

func _player() -> void:
	player = TidePlayer.new()
	player.setup(self)
	player.name = "Player"
	add_child(player)
	player.camera.current = true

func respawn_player() -> void:
	var p := ground_pos(1.5, 1.0, 1.1)
	player.global_position = p
	player.velocity = Vector3.ZERO
	player.yaw = 0.0
	if player.held:
		player.release_hold(false)

func ground_pos(x: float, z: float, lift: float) -> Vector3:
	var space := get_world_3d().direct_space_state
	var q := PhysicsRayQueryParameters3D.create(Vector3(x, 40, z), Vector3(x, -8, z))
	q.collision_mask = 1
	var hit := space.intersect_ray(q)
	if hit.is_empty():
		return Vector3(x, terrain_height(x, z) + lift, z)
	return hit.position + Vector3(0, lift, 0)

func camera_ray(dist: float) -> Dictionary:
	var cam: Camera3D = player.camera
	var from := cam.global_position
	var to := from + (-cam.global_basis.z) * dist
	var q := PhysicsRayQueryParameters3D.create(from, to)
	q.collision_mask = 1 | 2 | 8
	q.exclude = [player]
	if player.held:
		q.exclude.append(player.held)
	return get_world_3d().direct_space_state.intersect_ray(q)

func ui_blocks_point(pos: Vector2) -> bool:
	for c in ui_blockers:
		if is_instance_valid(c) and c.is_visible_in_tree() and c.get_global_rect().has_point(pos):
			return true
	return false

func spawn_count() -> int:
	return get_tree().get_nodes_in_group("spawned").size()

func spawn_prop(kind: String, at: Vector3, yaw: float) -> TideProp:
	var body := TideProp.new()
	body.setup(kind)
	body.position = at
	body.rotation.y = yaw
	add_child(body)
	body.add_to_group("spawned")
	body.add_to_group("prop")
	return body

func spawn_crab(at: Vector3, home: String) -> TideCrab:
	var body := TideCrab.new()
	body.setup(home)
	body.position = at
	add_child(body)
	return body

func clear_spawned() -> void:
	for n in get_tree().get_nodes_in_group("spawned"):
		n.remove_from_group("spawned")
		if n.is_in_group("crab"):
			n.remove_from_group("crab")
		if n.is_in_group("bottle"):
			n.remove_from_group("bottle")
		n.queue_free()
	for j in joints.get_children():
		j.queue_free()
	if player and player.held:
		player.held = null

func set_mode(next: String) -> void:
	mode = next
	won = false
	stable = 0.0
	warmup = 0.0
	win_left = 0.0
	if win_label:
		win_label.visible = false
	clear_spawned()
	_populate()

func _populate() -> void:
	var yard := ground_pos(3.2, -1.5, 0.5)
	if mode == "free" or mode == "tower":
		for i in (8 if mode == "tower" else 4):
			var p := ground_pos(3.0 + float(i % 4) * 1.05, -2.2 - float(i / 4) * 1.05, 0.5)
			spawn_prop("crate", p, 0.0)
	if mode == "free":
		spawn_prop("ball", ground_pos(0.2, -2.4, 0.5), 0.0)
		spawn_prop("spring", ground_pos(5.5, 2.2, 0.2), 0.0)
		spawn_prop("plank", ground_pos(4.2, 3.4, 0.2), 0.4)
		for i in 3:
			spawn_crab(ground_pos(-2.0 + float(i) * 1.6, 4.5, 0.35), "free")
		_bottles()
		var cannon := spawn_prop("cannon", ground_pos(-10.5, 9.2, 0.4), deg_to_rad(40.0))
		cannon.freeze = true
		_goal_ball(ground_pos(-1.0, -3.5, 0.5))
	elif mode == "ring":
		_goal_ball(ground_pos(2.2, -1.2, 0.5))
		spawn_prop("spring", ground_pos(4.5, 0.4, 0.2), 0.2)
		var ramp := spawn_prop("plank", ground_pos(6.2, 1.6, 0.3), 0.2)
		ramp.rotation = Vector3(deg_to_rad(-22), 0.2, 0)
	elif mode == "crabs":
		for i in 6:
			var b := spawn_prop("block", ground_pos(2.0 + float(i % 3) * 1.15, -2.0 - float(i / 3) * 1.15, 0.55), 0.0)
			b.freeze = true
		for i in 3:
			var ang := -0.4 + float(i) * 0.55
			spawn_crab(ground_pos(cos(ang) * 20.0, sin(ang) * 20.0, 0.4), "crabs")
	elif mode == "bottles":
		_bottles()
		var cannon2 := spawn_prop("cannon", ground_pos(-8.0, 6.5, 0.4), deg_to_rad(55.0))
		cannon2.freeze = true
		for i in 4:
			spawn_prop("ball", ground_pos(-6.5, 5.0 + float(i) * 0.7, 0.45), 0.0)
	_refresh_objective()
	play_sfx("pop")

func _goal_ball(at: Vector3) -> void:
	var b := spawn_prop("ball", at, 0.0)
	b.set_meta("goal", true)
	var mesh := b.get_node_or_null("Mesh")
	if mesh is MeshInstance3D:
		var m := StandardMaterial3D.new()
		m.albedo_color = Color("e2b15a")
		m.metallic = 0.85
		m.roughness = 0.22
		m.emission_enabled = true
		m.emission = Color("e2b15a")
		m.emission_energy_multiplier = 0.35
		mesh.material_override = m

func _bottles() -> void:
	for i in 5:
		var at := ground_pos(-15.0 + float(i - 2) * 0.55, 11.0, 0.45)
		var b := spawn_prop("ball", at, 0.0)
		b.mass = 0.35
		b.continuous_cd = false
		var col := b.get_node("Col")
		var cyl_shape := CylinderShape3D.new()
		cyl_shape.radius = 0.11
		cyl_shape.height = 0.52
		col.shape = cyl_shape
		var mesh := b.get_node("Mesh")
		var cyl := CylinderMesh.new()
		cyl.top_radius = 0.1
		cyl.bottom_radius = 0.12
		cyl.height = 0.52
		mesh.mesh = cyl
		var m := StandardMaterial3D.new()
		m.albedo_color = Color("d7efe8")
		m.roughness = 0.18
		m.metallic = 0.05
		m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
		m.albedo_color.a = 0.88
		mesh.material_override = m
		b.add_to_group("bottle")

func _refresh_objective() -> void:
	if obj_label == null:
		return
	match mode:
		"ring":
			obj_label.text = "Кольцо. Закинь золотой шар."
		"tower":
			obj_label.text = "Башня. Шесть ящиков должны устоять."
		"crabs":
			obj_label.text = "Прилив. Удержи крабов на острове."
		"bottles":
			obj_label.text = "Бутылки. Сбей все на площадке."
		_:
			obj_label.text = "Свободная верфь. Клей, лёд, пушки."

func place_tool() -> void:
	if spawn_count() > 78:
		_status("Слишком много деталей")
		return
	var kind: String = TOOLS[tool_i][0]
	var hit := camera_ray(26.0)
	var yaw := player.yaw + place_extra
	var p: Vector3
	if hit.is_empty():
		var dir := -player.camera.global_basis.z
		dir.y = 0.0
		if dir.length() < 0.01:
			dir = Vector3(0, 0, -1)
		dir = dir.normalized()
		var guess := player.global_position + dir * 4.0
		p = ground_pos(guess.x, guess.z, 0.5)
	else:
		p = hit.position
		if grid_on:
			p.x = snapped(p.x, 0.5)
			p.z = snapped(p.z, 0.5)
		p = ground_pos(p.x, p.z, 0.4)
	if kind == "crab":
		spawn_crab(p + Vector3(0, 0.2, 0), "free" if mode != "crabs" else "crabs")
	else:
		var body := spawn_prop(kind, p, yaw)
		p = ground_pos(p.x, p.z, body.half_height())
		body.global_position = p
		if kind == "ball" and mode == "ring" and not _has_goal():
			body.set_meta("goal", true)
	play_sfx("place")

func _has_goal() -> bool:
	for n in get_tree().get_nodes_in_group("spawned"):
		if n.get_meta("goal", false):
			return true
	return false

func delete_looked() -> void:
	var hit := camera_ray(30.0)
	if hit.is_empty():
		return
	var b = hit.collider
	if b is RigidBody3D and (b.is_in_group("spawned") or b.is_in_group("crab")):
		if player.held == b:
			player.held = null
		b.queue_free()
		play_sfx("pop")

func freeze_looked() -> void:
	var hit := camera_ray(30.0)
	if hit.is_empty():
		return
	var b = hit.collider
	if b is RigidBody3D and b.is_in_group("prop"):
		b.freeze = not b.freeze
		if b.freeze:
			b.freeze_mode = RigidBody3D.FREEZE_MODE_STATIC
		_status("Заморожено" if b.freeze else "Снова живое")

func glue_looked() -> void:
	var hit := camera_ray(24.0)
	if hit.is_empty():
		return
	var a = hit.collider
	if not (a is RigidBody3D):
		return
	var best: RigidBody3D
	var best_d := 2.4
	for n in get_tree().get_nodes_in_group("spawned"):
		if n == a or not (n is RigidBody3D):
			continue
		var body := n as RigidBody3D
		var d := body.global_position.distance_to(a.global_position)
		if d < best_d:
			best_d = d
			best = n
	if best == null:
		_status("Рядом не к чему клеить")
		return
	var j := PinJoint3D.new()
	joints.add_child(j)
	j.global_position = (a.global_position + best.global_position) * 0.5
	j.node_a = j.get_path_to(a)
	j.node_b = j.get_path_to(best)
	if a.get("links") != null:
		a.links.append(j)
	if best.get("links") != null:
		best.links.append(j)
	play_sfx("place")
	_status("Склеено")

func rotate_tool(dir: int) -> void:
	place_extra += deg_to_rad(15.0) * float(dir)

func cycle_tool(dir: int) -> void:
	tool_i = posmod(tool_i + dir, TOOLS.size())
	_paint_slots()

func select_tool(i: int) -> void:
	if i < 0 or i >= TOOLS.size():
		return
	tool_i = i
	_paint_slots()

func toggle_grid() -> void:
	grid_on = not grid_on
	_status("Сетка вкл" if grid_on else "Сетка выкл")

func blueprint() -> void:
	var f := Vector3(-sin(player.yaw), 0, -cos(player.yaw))
	var r := Vector3(cos(player.yaw), 0, -sin(player.yaw))
	var origin := player.global_position + f * 3.6
	match bp % 4:
		0:
			var ramp := spawn_prop("plank", ground_pos(origin.x, origin.z, 0.3), player.yaw)
			var x_axis := (f + Vector3.UP * 0.38).normalized()
			var z_axis := x_axis.cross(Vector3.UP).normalized()
			var y_axis := z_axis.cross(x_axis).normalized()
			ramp.global_transform = Transform3D(Basis(x_axis, y_axis, z_axis), ramp.global_position)
			spawn_prop("spring", ground_pos((origin - f * 1.4).x, (origin - f * 1.4).z, 0.2), player.yaw)
			_status("Чертёж: трамплин")
		1:
			for i in 5:
				var pos := origin + r * (float(i) - 2.0) * 1.05
				var block := spawn_prop("block", ground_pos(pos.x, pos.z, 0.55), player.yaw)
				block.freeze = true
			_status("Чертёж: стена")
		2:
			for i in 8:
				var pos2 := origin + r * float(i) * 0.95
				spawn_prop("crate", ground_pos(pos2.x, pos2.z, 0.5), player.yaw)
			_status("Чертёж: домино")
		_:
			var ice := spawn_prop("ice", ground_pos(origin.x, origin.z, 0.16), player.yaw)
			ice.freeze = true
			var c := spawn_prop("cannon", ground_pos((origin + f * 0.4).x, (origin + f * 0.4).z, 0.5), player.yaw)
			c.freeze = true
			_status("Чертёж: пушка")
	bp += 1
	play_sfx("place")

func boom(at: Vector3) -> void:
	play_sfx("boom")
	player.shake = maxf(player.shake, clampf(1.3 - player.global_position.distance_to(at) * 0.12, 0.0, 0.7))
	for n in get_tree().get_nodes_in_group("spawned"):
		if not is_instance_valid(n) or not (n is RigidBody3D):
			continue
		var body := n as RigidBody3D
		if body.global_position.distance_to(at) > 7.5:
			continue
		var dir := body.global_position - at
		var d := maxf(dir.length(), 0.45)
		dir = dir.normalized()
		body.sleeping = false
		body.freeze = false
		body.apply_central_impulse(dir * body.mass * (11.0 / d) + Vector3.UP * body.mass * 2.4)
	if player.global_position.distance_to(at) < 6.5:
		var pd := (player.global_position - at).normalized()
		player.velocity += pd * 9.0 + Vector3.UP * 5.5
	_puff(at, Color("e07a3d"))

func cannon_shot(from: Vector3, dir: Vector3, ignore: Node) -> void:
	if dir.length() < 0.01:
		return
	var ball := spawn_prop("ball", from, 0.0)
	ball.set_meta("nosave", true)
	ball.life = 5.5
	ball.mass = 1.3
	var col := ball.get_node("Col")
	if col.shape is SphereShape3D:
		col.shape.radius = 0.2
	var mesh := ball.get_node("Mesh")
	if mesh.mesh is SphereMesh:
		mesh.mesh.radius = 0.2
		mesh.mesh.height = 0.4
	ball.linear_velocity = dir.normalized() * 20.0
	if ignore is CollisionObject3D:
		ball.add_collision_exception_with(ignore)
	play_sfx("pop")

func _puff(at: Vector3, color: Color) -> void:
	var p := CPUParticles3D.new()
	p.one_shot = true
	p.explosiveness = 0.92
	p.amount = 22
	p.lifetime = 0.55
	p.direction = Vector3.UP
	p.spread = 78.0
	p.initial_velocity_min = 2.0
	p.initial_velocity_max = 7.0
	p.gravity = Vector3(0, -5, 0)
	var sm := SphereMesh.new()
	sm.radius = 0.07
	sm.height = 0.14
	p.mesh = sm
	var m := StandardMaterial3D.new()
	m.albedo_color = color
	m.emission_enabled = true
	m.emission = color
	m.emission_energy_multiplier = 0.8
	p.material_override = m
	add_child(p)
	p.global_position = at
	p.emitting = true
	get_tree().create_timer(1.2).timeout.connect(p.queue_free)

func _tide(dt: float) -> void:
	tide_phase = fposmod(tide_phase + dt / 50.0, 1.0)
	var active := tide_phase >= 0.78 and tide_phase < 0.93
	var warn := tide_phase >= 0.66 and tide_phase < 0.78
	var pulse := 0.0
	if active:
		var u := (tide_phase - 0.78) / 0.15
		pulse = sin(u * PI)
	if tide_active and not active and warmup > 2.0:
		_tide_finished()
	tide_active = active
	water_y = 0.42 + pulse * 1.25
	if water:
		water.position.y = water_y
	if tide_bar:
		tide_bar.value = tide_phase * 100.0
	if active:
		tide_note = "ПРИЛИВ"
	elif warn:
		tide_note = "Скоро волна"
	else:
		tide_note = "Отлив"
	if tide_label:
		tide_label.text = tide_note
	if not active:
		return
	for n in get_tree().get_nodes_in_group("spawned"):
		if not (n is RigidBody3D) or not is_instance_valid(n):
			continue
		var body := n as RigidBody3D
		if body.freeze:
			continue
		var radial := Vector3(body.global_position.x, 0, body.global_position.z)
		var dist := radial.length()
		if dist < 15.0 or body.global_position.y > water_y + 1.6:
			continue
		var shore := clampf((dist - 15.0) / 16.0, 0.0, 1.0)
		var push := radial.normalized() * body.mass * 26.0 * shore + Vector3.UP * body.mass * 12.0 * shore
		body.apply_central_force(push)

func _buoy() -> void:
	for n in get_tree().get_nodes_in_group("prop"):
		if not is_instance_valid(n) or not (n is RigidBody3D):
			continue
		if n.freeze or n.kind == "balloon":
			continue
		if n.global_position.y < water_y:
			var depth := clampf(water_y - n.global_position.y, 0.0, 1.4)
			n.apply_central_force(Vector3.UP * n.mass * 20.0 * depth)

func _tide_finished() -> void:
	if mode != "crabs" or won:
		return
	var safe := 0
	var total := 0
	for c in get_tree().get_nodes_in_group("crab"):
		total += 1
		if _crab_safe(c):
			safe += 1
	if total >= 3 and safe >= 3:
		win("Крабы пережили волну.")
	else:
		_status("Волна забрала крабов: %d на острове" % safe)

func _crab_safe(c: Node) -> bool:
	var p: Vector3 = c.global_position
	return Vector2(p.x, p.z).length() < 31.0 and p.y > 0.35 and p.y < 18.0

func _goals(dt: float) -> void:
	if won or warmup < 1.2:
		return
	if mode == "tower":
		if _tower_ok():
			stable += dt
			_status("Держится %.1f / 2.5" % stable)
			if stable >= 2.5:
				win("Башня стоит.")
		else:
			stable = 0.0
			_status("Нужна стопка из шести ящиков")
	elif mode == "bottles":
		var up := 0
		var total := 0
		for b in get_tree().get_nodes_in_group("bottle"):
			if not is_instance_valid(b):
				continue
			total += 1
			if b.global_transform.basis.y.dot(Vector3.UP) > 0.7:
				up += 1
		_status("Стоят %d из %d" % [up, total])
		if total > 0 and up == 0:
			win("Все бутылки лежат.")
	elif mode == "crabs":
		var safe := 0
		var total2 := 0
		for c in get_tree().get_nodes_in_group("crab"):
			total2 += 1
			if _crab_safe(c):
				safe += 1
		_status("На острове %d / %d · %s" % [safe, total2, tide_note])

func _tower_ok() -> bool:
	var crates: Array = []
	for n in get_tree().get_nodes_in_group("spawned"):
		if n is RigidBody3D and str(n.kind) == "crate" and n.linear_velocity.length() < 0.5:
			crates.append(n)
	if crates.size() < 6:
		return false
	crates.sort_custom(func(a, b): return a.global_position.y < b.global_position.y)
	var base: Vector3 = crates[0].global_position
	var prev_y := base.y
	var count := 1
	for i in range(1, crates.size()):
		var p: Vector3 = crates[i].global_position
		if Vector2(p.x - base.x, p.z - base.z).length() > 1.2:
			continue
		if p.y - prev_y < 0.55:
			continue
		prev_y = p.y
		count += 1
	return count >= 6

func win(text: String) -> void:
	if won:
		return
	won = true
	play_sfx("win")
	if win_label:
		win_label.text = text
		win_label.visible = true
		win_left = 5.0
	_status(text)

func _status(text: String) -> void:
	if status_label:
		status_label.text = text

func _ghost() -> void:
	if ghost == null:
		return
	var kind: String = TOOLS[tool_i][0]
	if str(ghost.get_meta("kind", "")) != kind:
		ghost.set_meta("kind", kind)
		ghost.mesh = _ghost_mesh(kind)
	var hit := camera_ray(26.0)
	if hit.is_empty():
		ghost.visible = false
		return
	var p: Vector3 = hit.position
	if grid_on:
		p.x = snapped(p.x, 0.5)
		p.z = snapped(p.z, 0.5)
	ghost.visible = true
	ghost.global_position = p + Vector3(0, 0.35, 0)
	ghost.rotation.y = player.yaw + place_extra

func _ghost_mesh(kind: String) -> Mesh:
	match kind:
		"ball", "bomb", "balloon", "crab":
			var s := SphereMesh.new()
			s.radius = 0.35 if kind != "balloon" else 0.5
			s.height = s.radius * 2.0
			return s
		"plank":
			var b := BoxMesh.new()
			b.size = Vector3(2.5, 0.16, 0.62)
			return b
		"ice":
			var b2 := BoxMesh.new()
			b2.size = Vector3(2.2, 0.18, 2.2)
			return b2
		"cannon":
			var b3 := BoxMesh.new()
			b3.size = Vector3(0.7, 0.45, 1.1)
			return b3
		_:
			var b4 := BoxMesh.new()
			b4.size = Vector3(0.9, 0.9, 0.9)
			return b4

func save_yard() -> void:
	var props := []
	for n in get_tree().get_nodes_in_group("spawned"):
		if not is_instance_valid(n) or bool(n.get_meta("nosave", false)):
			continue
		var kind := "crab" if n.is_in_group("crab") else str(n.get("kind"))
		if kind == "":
			continue
		props.append({
			"k": kind,
			"p": [n.global_position.x, n.global_position.y, n.global_position.z],
			"y": n.rotation.y,
			"f": bool(n.freeze) if n is RigidBody3D else false,
			"g": bool(n.get_meta("goal", false)),
		})
	var text := JSON.stringify({"v": 1, "mode": mode, "props": props})
	var f := FileAccess.open("user://tideyard.save", FileAccess.WRITE)
	if f:
		f.store_string(text)
	if OS.has_feature("web"):
		var b64 := Marshalls.utf8_to_base64(text)
		JavaScriptBridge.eval("localStorage.setItem('tideyard','%s')" % b64, true)
	_status("Верфь сохранена")

func load_yard() -> void:
	var text := ""
	if OS.has_feature("web"):
		var b64 = JavaScriptBridge.eval("localStorage.getItem('tideyard')||''", true)
		if b64 != null and str(b64) != "":
			text = Marshalls.base64_to_utf8(str(b64))
	if text == "":
		var f := FileAccess.open("user://tideyard.save", FileAccess.READ)
		if f:
			text = f.get_as_text()
	if text == "":
		_status("Нет сохранения")
		return
	var data = JSON.parse_string(text)
	if typeof(data) != TYPE_DICTIONARY:
		_status("Сохранение битое")
		return
	clear_spawned()
	for item in data.get("props", []):
		var k := str(item.get("k", "crate"))
		var p: Array = item.get("p", [0, 2, 0])
		var at := Vector3(float(p[0]), float(p[1]), float(p[2]))
		var yaw := float(item.get("y", 0.0))
		if k == "crab":
			spawn_crab(at, mode)
		else:
			var body := spawn_prop(k, at, yaw)
			body.freeze = bool(item.get("f", false))
			if bool(item.get("g", false)):
				body.set_meta("goal", true)
	_status("Верфь загружена")

func toggle_help() -> void:
	if help_root:
		help_root.visible = not help_root.visible

func show_joy(origin: Vector2) -> void:
	if joy == null:
		return
	joy.visible = true
	joy.position = origin - Vector2(46, 46)
	joy_knob.position = Vector2(28, 28)

func move_joy(pos: Vector2) -> void:
	if joy == null or not joy.visible:
		return
	var center := joy.position + Vector2(46, 46)
	var d := pos - center
	if d.length() > 36.0:
		d = d.normalized() * 36.0
	joy_knob.position = Vector2(28, 28) + d

func hide_joy() -> void:
	if joy:
		joy.visible = false

func _ui() -> void:
	var layer := CanvasLayer.new()
	layer.process_mode = Node.PROCESS_MODE_ALWAYS
	add_child(layer)
	var theme := Theme.new()
	var font = load("res://fonts/Rubik.ttf")
	if font:
		theme.default_font = font
	theme.default_font_size = 16
	var ui := Control.new()
	ui.set_anchors_preset(Control.PRESET_FULL_RECT)
	ui.mouse_filter = Control.MOUSE_FILTER_IGNORE
	ui.theme = theme
	layer.add_child(ui)
	obj_label = Label.new()
	obj_label.set_anchors_preset(Control.PRESET_TOP_WIDE)
	obj_label.offset_left = 16
	obj_label.offset_right = -16
	obj_label.offset_top = 14
	obj_label.offset_bottom = 46
	obj_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	obj_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	obj_label.add_theme_color_override("font_color", Color("e7f3ee"))
	obj_label.add_theme_font_size_override("font_size", 20)
	obj_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	ui.add_child(obj_label)
	status_label = Label.new()
	status_label.set_anchors_preset(Control.PRESET_TOP_WIDE)
	status_label.offset_top = 46
	status_label.offset_bottom = 74
	status_label.offset_left = 16
	status_label.offset_right = -16
	status_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	status_label.add_theme_color_override("font_color", Color("e2b15a"))
	status_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	ui.add_child(status_label)
	tide_label = Label.new()
	tide_label.set_anchors_preset(Control.PRESET_TOP_LEFT)
	tide_label.position = Vector2(16, 78)
	tide_label.size = Vector2(160, 24)
	tide_label.add_theme_color_override("font_color", Color("9fd0d4"))
	tide_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	tide_label.text = "Отлив"
	ui.add_child(tide_label)
	tide_bar = ProgressBar.new()
	tide_bar.set_anchors_preset(Control.PRESET_TOP_LEFT)
	tide_bar.position = Vector2(16, 102)
	tide_bar.size = Vector2(140, 10)
	tide_bar.max_value = 100
	tide_bar.value = 15
	tide_bar.show_percentage = false
	tide_bar.mouse_filter = Control.MOUSE_FILTER_IGNORE
	ui.add_child(tide_bar)
	var help_btn := _btn("Помощь")
	help_btn.set_anchors_preset(Control.PRESET_TOP_RIGHT)
	help_btn.offset_left = -132
	help_btn.offset_right = -16
	help_btn.offset_top = 14
	help_btn.offset_bottom = 58
	help_btn.pressed.connect(toggle_help)
	ui.add_child(help_btn)
	ui_blockers.append(help_btn)
	var grid := GridContainer.new()
	hotbar = grid
	grid.columns = 5
	grid.set_anchors_preset(Control.PRESET_CENTER_BOTTOM)
	grid.offset_left = -180
	grid.offset_right = 180
	grid.offset_top = -168
	grid.offset_bottom = -62
	grid.add_theme_constant_override("h_separation", 6)
	grid.add_theme_constant_override("v_separation", 6)
	grid.mouse_filter = Control.MOUSE_FILTER_IGNORE
	ui.add_child(grid)
	ui_blockers.append(grid)
	for i in TOOLS.size():
		var b := _btn(TOOLS[i][1])
		b.custom_minimum_size = Vector2(68, 48)
		var idx := i
		b.pressed.connect(func(): select_tool(idx))
		grid.add_child(b)
		slots.append(b)
	_paint_slots()
	hint_label = Label.new()
	hint_label.set_anchors_preset(Control.PRESET_CENTER_BOTTOM)
	hint_label.offset_top = -56
	hint_label.offset_bottom = -28
	hint_label.offset_left = -280
	hint_label.offset_right = 280
	hint_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	hint_label.add_theme_color_override("font_color", Color("b7c9c2"))
	hint_label.add_theme_font_size_override("font_size", 13)
	hint_label.text = "ЛКМ хват · ПКМ поставить · R поворот · B клей · F полёт"
	hint_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	ui.add_child(hint_label)
	win_label = Label.new()
	win_label.set_anchors_preset(Control.PRESET_CENTER)
	win_label.offset_left = -220
	win_label.offset_right = 220
	win_label.offset_top = -36
	win_label.offset_bottom = 36
	win_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	win_label.add_theme_font_size_override("font_size", 28)
	win_label.add_theme_color_override("font_color", Color("e2b15a"))
	win_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	win_label.visible = false
	ui.add_child(win_label)
	_help(ui)
	_touch(ui)
	ghost = MeshInstance3D.new()
	var gm := StandardMaterial3D.new()
	gm.albedo_color = Color(0.878, 0.694, 0.353, 0.35)
	gm.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	gm.roughness = 0.4
	ghost.material_override = gm
	ghost.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(ghost)
	ghost.visible = false
	get_viewport().size_changed.connect(_layout)
	_layout()

func _help(host: Control) -> void:
	help_root = Control.new()
	help_root.set_anchors_preset(Control.PRESET_FULL_RECT)
	help_root.visible = false
	help_root.mouse_filter = Control.MOUSE_FILTER_STOP
	host.add_child(help_root)
	ui_blockers.append(help_root)
	var dim := ColorRect.new()
	dim.set_anchors_preset(Control.PRESET_FULL_RECT)
	dim.color = Color(0.06, 0.12, 0.14, 0.78)
	dim.mouse_filter = Control.MOUSE_FILTER_IGNORE
	help_root.add_child(dim)
	var panel := PanelContainer.new()
	panel.set_anchors_preset(Control.PRESET_FULL_RECT)
	panel.offset_left = 18
	panel.offset_right = -18
	panel.offset_top = 72
	panel.offset_bottom = -72
	var style := StyleBoxFlat.new()
	style.bg_color = Color("17343d")
	style.corner_radius_top_left = 18
	style.corner_radius_top_right = 18
	style.corner_radius_bottom_left = 18
	style.corner_radius_bottom_right = 18
	style.content_margin_left = 16
	style.content_margin_right = 16
	style.content_margin_top = 14
	style.content_margin_bottom = 14
	panel.add_theme_stylebox_override("panel", style)
	help_root.add_child(panel)
	var box := VBoxContainer.new()
	box.add_theme_constant_override("separation", 8)
	panel.add_child(box)
	var title := Label.new()
	title.text = "Верфь"
	title.add_theme_font_size_override("font_size", 22)
	title.add_theme_color_override("font_color", Color("e7f3ee"))
	box.add_child(title)
	var body := Label.new()
	body.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	body.text = "WASD — шаг, пробел — прыжок, шифт — бег. Зажми ПКМ и води, чтобы смотреть. ЛКМ держит деталь, T бросает. ПКМ без движения ставит выбранное. R крутит, G сетка, C мороз, B клей, V чертёж, F полёт, M мышь. На телефоне левый стик — ход, правая половина — обзор."
	body.add_theme_color_override("font_color", Color("d5e6df"))
	body.custom_minimum_size = Vector2(0, 0)
	box.add_child(body)
	var row1 := HBoxContainer.new()
	row1.add_theme_constant_override("separation", 6)
	box.add_child(row1)
	_mode_btn(row1, "Свободно", "free")
	_mode_btn(row1, "Кольцо", "ring")
	_mode_btn(row1, "Башня", "tower")
	var row2 := HBoxContainer.new()
	row2.add_theme_constant_override("separation", 6)
	box.add_child(row2)
	_mode_btn(row2, "Крабы", "crabs")
	_mode_btn(row2, "Бутылки", "bottles")
	var row3 := HBoxContainer.new()
	row3.add_theme_constant_override("separation", 6)
	box.add_child(row3)
	var save_b := _btn("Сохранить")
	save_b.pressed.connect(save_yard)
	row3.add_child(save_b)
	var load_b := _btn("Загрузить")
	load_b.pressed.connect(load_yard)
	row3.add_child(load_b)
	var plan_b := _btn("Чертёж")
	plan_b.pressed.connect(blueprint)
	row3.add_child(plan_b)
	var close_b := _btn("Закрыть")
	close_b.pressed.connect(toggle_help)
	box.add_child(close_b)

func _mode_btn(row: HBoxContainer, text: String, id: String) -> void:
	var b := _btn(text)
	b.pressed.connect(func():
		set_mode(id)
		toggle_help()
	)
	row.add_child(b)

func _touch(host: Control) -> void:
	touch_root = Control.new()
	touch_root.set_anchors_preset(Control.PRESET_FULL_RECT)
	touch_root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	touch_root.visible = false
	host.add_child(touch_root)
	joy = Control.new()
	joy.custom_minimum_size = Vector2(92, 92)
	joy.size = Vector2(92, 92)
	joy.visible = false
	joy.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var base := ColorRect.new()
	base.color = Color(0.91, 0.95, 0.93, 0.18)
	base.set_anchors_preset(Control.PRESET_FULL_RECT)
	base.mouse_filter = Control.MOUSE_FILTER_IGNORE
	joy.add_child(base)
	joy_knob = ColorRect.new()
	joy_knob.color = Color("e2b15a")
	joy_knob.size = Vector2(36, 36)
	joy_knob.position = Vector2(28, 28)
	joy_knob.mouse_filter = Control.MOUSE_FILTER_IGNORE
	joy.add_child(joy_knob)
	touch_root.add_child(joy)
	var cluster := GridContainer.new()
	cluster.columns = 3
	cluster.set_anchors_preset(Control.PRESET_BOTTOM_RIGHT)
	cluster.offset_left = -250
	cluster.offset_right = -12
	cluster.offset_top = -168
	cluster.offset_bottom = -16
	cluster.add_theme_constant_override("h_separation", 6)
	cluster.add_theme_constant_override("v_separation", 6)
	cluster.mouse_filter = Control.MOUSE_FILTER_IGNORE
	touch_root.add_child(cluster)
	ui_blockers.append(cluster)
	var specs := [
		["Прыжок", func(): player.tap_jump = true],
		["Полёт", func(): player.fly = not player.fly],
		["Хват", func(): player.touch_grab()],
		["Бросок", func(): player.touch_throw()],
		["Ставить", func(): place_tool()],
		["Снести", func(): delete_looked()],
	]
	for spec in specs:
		var b := _btn(spec[0])
		b.custom_minimum_size = Vector2(74, 48)
		b.pressed.connect(spec[1])
		cluster.add_child(b)

func _layout() -> void:
	var w := get_viewport().get_visible_rect().size.x
	var touch := w < 980.0
	if touch_root:
		touch_root.visible = touch
	if hotbar:
		if touch:
			hotbar.offset_top = -250
			hotbar.offset_bottom = -148
			hotbar.offset_left = -160
			hotbar.offset_right = 160
		else:
			hotbar.offset_top = -150
			hotbar.offset_bottom = -48
			hotbar.offset_left = -200
			hotbar.offset_right = 200
	if hint_label:
		hint_label.visible = not touch
		if not touch:
			hint_label.offset_top = -40
			hint_label.offset_bottom = -14
	var slot := 60.0 if touch else 74.0
	for b in slots:
		b.custom_minimum_size = Vector2(slot, 46 if touch else 52)

func _paint_slots() -> void:
	for i in slots.size():
		var on := i == tool_i
		slots[i].add_theme_color_override("font_color", Color("2a140c") if on else Color("e7f3ee"))
		var style := StyleBoxFlat.new()
		style.bg_color = Color("e07a3d") if on else Color("17343d")
		style.corner_radius_top_left = 10
		style.corner_radius_top_right = 10
		style.corner_radius_bottom_left = 10
		style.corner_radius_bottom_right = 10
		slots[i].add_theme_stylebox_override("normal", style)
		slots[i].add_theme_stylebox_override("hover", style)
		slots[i].add_theme_stylebox_override("pressed", style)
		slots[i].add_theme_stylebox_override("focus", style)

func _btn(text: String) -> Button:
	var b := Button.new()
	b.text = text
	b.focus_mode = Control.FOCUS_NONE
	var style := StyleBoxFlat.new()
	style.bg_color = Color("17343d")
	style.corner_radius_top_left = 12
	style.corner_radius_top_right = 12
	style.corner_radius_bottom_left = 12
	style.corner_radius_bottom_right = 12
	style.content_margin_left = 10
	style.content_margin_right = 10
	style.content_margin_top = 8
	style.content_margin_bottom = 8
	b.add_theme_stylebox_override("normal", style)
	b.add_theme_stylebox_override("hover", style)
	b.add_theme_stylebox_override("pressed", style)
	b.add_theme_stylebox_override("focus", style)
	b.add_theme_color_override("font_color", Color("e7f3ee"))
	b.add_theme_color_override("font_hover_color", Color("e2b15a"))
	return b
