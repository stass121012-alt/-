class_name TidePlayer
extends CharacterBody3D

var world
var yaw := 0.0
var pitch_ang := -0.32
var camera: Camera3D
var model: Node3D
var stick := Vector2.ZERO
var look_dx := 0.0
var look_dy := 0.0
var hold_dist := 4.2
var held
var saved_layer := 0
var saved_mask := 0
var fly := false
var rmb := false
var rmb_moved := 0.0
var fingers := {}
var injected: Array = []
var tap_jump := false
var shake := 0.0
const SENS := 0.0032
const WALK := 7.4
const SPRINT := 11.2

func setup(w: Node) -> void:
	world = w
	collision_layer = 4
	collision_mask = 1 | 2 | 8
	floor_max_angle = deg_to_rad(54.0)
	floor_snap_length = 0.28
	floor_stop_on_slope = true
	var col := CollisionShape3D.new()
	var cap := CapsuleShape3D.new()
	cap.radius = 0.34
	cap.height = 1.5
	col.shape = cap
	add_child(col)
	model = Node3D.new()
	model.name = "Model"
	add_child(model)
	_part(Vector3(0.32, 0.95, 0.32), Vector3(0, 0.05, 0), Color("1e6e58"), "cap")
	_part(Vector3(0.22, 0.22, 0.22), Vector3(0, 0.72, 0), Color("e6c2a2"), "sphere")
	_part(Vector3(0.28, 0.34, 0.18), Vector3(0, 0.28, 0.22), Color("6b3a22"), "box")
	_part(Vector3(0.26, 0.1, 0.12), Vector3(0, 0.74, -0.16), Color("e2b15a"), "box")
	_part(Vector3(0.1, 0.18, 0.22), Vector3(0, 0.86, -0.2), Color("e07a3d"), "box")
	_part(Vector3(0.16, 0.14, 0.22), Vector3(-0.12, -0.52, 0.02), Color("2a2420"), "box")
	_part(Vector3(0.16, 0.14, 0.22), Vector3(0.12, -0.52, 0.02), Color("2a2420"), "box")
	camera = Camera3D.new()
	camera.fov = 68.0
	camera.near = 0.08
	camera.far = 320.0
	add_child(camera)

func _part(size: Vector3, pos: Vector3, color: Color, shape: String) -> void:
	var mi := MeshInstance3D.new()
	if shape == "sphere":
		var sm := SphereMesh.new()
		sm.radius = size.x
		sm.height = size.x * 2.0
		mi.mesh = sm
	elif shape == "cap":
		var cm := CapsuleMesh.new()
		cm.radius = size.x
		cm.height = size.y
		mi.mesh = cm
	else:
		var bm := BoxMesh.new()
		bm.size = size
		mi.mesh = bm
	mi.position = pos
	var m := StandardMaterial3D.new()
	m.albedo_color = color
	m.roughness = 0.7
	mi.material_override = m
	model.add_child(mi)

func _unhandled_input(event: InputEvent) -> void:
	if world == null:
		return
	if event is InputEventMouseButton:
		var mb := event as InputEventMouseButton
		if world.has_method("ui_blocks_point") and world.ui_blocks_point(mb.position) and mb.pressed:
			return
		if mb.button_index == MOUSE_BUTTON_RIGHT:
			if mb.pressed:
				rmb = true
				rmb_moved = 0.0
			else:
				rmb = false
				if rmb_moved < 10.0:
					world.place_tool()
			return
		if mb.button_index == MOUSE_BUTTON_LEFT:
			if mb.pressed:
				begin_grab()
			else:
				release_hold(false)
			return
		if mb.pressed and held == null:
			if mb.button_index == MOUSE_BUTTON_WHEEL_UP:
				world.cycle_tool(-1)
			elif mb.button_index == MOUSE_BUTTON_WHEEL_DOWN:
				world.cycle_tool(1)
		elif mb.pressed and held != null:
			if mb.button_index == MOUSE_BUTTON_WHEEL_UP:
				hold_dist = minf(hold_dist + 0.4, 12.0)
			elif mb.button_index == MOUSE_BUTTON_WHEEL_DOWN:
				hold_dist = maxf(hold_dist - 0.4, 2.0)
		return
	if event is InputEventMouseMotion:
		var mm := event as InputEventMouseMotion
		if rmb or Input.mouse_mode == Input.MOUSE_MODE_CAPTURED:
			look_dx += mm.relative.x
			look_dy += mm.relative.y
			rmb_moved += mm.relative.length()
		return
	if event is InputEventScreenTouch:
		var st := event as InputEventScreenTouch
		if st.pressed:
			if world.has_method("ui_blocks_point") and world.ui_blocks_point(st.position):
				return
			var zone := "move" if st.position.x < get_viewport().get_visible_rect().size.x * 0.46 else "look"
			fingers[st.index] = {"zone": zone, "origin": st.position}
			if zone == "move" and world.has_method("show_joy"):
				world.show_joy(st.position)
		else:
			if fingers.has(st.index) and str(fingers[st.index].zone) == "move":
				stick = Vector2.ZERO
				if world.has_method("hide_joy"):
					world.hide_joy()
			fingers.erase(st.index)
		return
	if event is InputEventScreenDrag:
		var sd := event as InputEventScreenDrag
		if not fingers.has(sd.index):
			return
		var f: Dictionary = fingers[sd.index]
		if str(f.zone) == "move":
			var d: Vector2 = sd.position - f.origin
			stick = Vector2(clampf(d.x / 68.0, -1.0, 1.0), clampf(-d.y / 68.0, -1.0, 1.0))
			if world.has_method("move_joy"):
				world.move_joy(sd.position)
		else:
			look_dx += sd.relative.x
			look_dy += sd.relative.y
		return
	if event is InputEventKey and event.pressed and not event.echo:
		var key := event as InputEventKey
		var code := key.physical_keycode
		match code:
			KEY_F:
				fly = not fly
			KEY_R:
				world.rotate_tool(1)
			KEY_G:
				world.toggle_grid()
			KEY_X, KEY_DELETE, KEY_BACKSPACE:
				world.delete_looked()
			KEY_C:
				world.freeze_looked()
			KEY_B:
				world.glue_looked()
			KEY_V:
				world.blueprint()
			KEY_T:
				if held:
					release_hold(true)
			KEY_H:
				world.toggle_help()
			KEY_ESCAPE:
				if Input.mouse_mode == Input.MOUSE_MODE_CAPTURED:
					Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
				else:
					world.toggle_help()
			KEY_1: world.select_tool(0)
			KEY_2: world.select_tool(1)
			KEY_3: world.select_tool(2)
			KEY_4: world.select_tool(3)
			KEY_5: world.select_tool(4)
			KEY_6: world.select_tool(5)
			KEY_7: world.select_tool(6)
			KEY_8: world.select_tool(7)
			KEY_9: world.select_tool(8)
			KEY_0: world.select_tool(9)
			KEY_M:
				_toggle_capture()

func _toggle_capture() -> void:
	if Input.mouse_mode == Input.MOUSE_MODE_CAPTURED:
		Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	else:
		Input.mouse_mode = Input.MOUSE_MODE_CAPTURED

func _physics_process(dt: float) -> void:
	dt = minf(dt, 0.05)
	_refresh_injected()
	yaw -= look_dx * SENS
	pitch_ang = clampf(pitch_ang - look_dy * SENS, -1.05, 0.72)
	look_dx = 0.0
	look_dy = 0.0
	var forward := Vector3(-sin(yaw), 0.0, -cos(yaw))
	var right := Vector3(cos(yaw), 0.0, -sin(yaw))
	var ix := stick.x
	var iz := stick.y
	if _down("KeyA"):
		ix -= 1.0
	if _down("KeyD"):
		ix += 1.0
	if _down("KeyW"):
		iz += 1.0
	if _down("KeyS"):
		iz -= 1.0
	ix = clampf(ix, -1.0, 1.0)
	iz = clampf(iz, -1.0, 1.0)
	var wish := forward * iz + right * ix
	if wish.length() > 1.0:
		wish = wish.normalized()
	var speed := SPRINT if (_down("ShiftLeft") or _down("ShiftRight")) else WALK
	var jumped := tap_jump or _down("Space")
	tap_jump = false
	if fly:
		var vy := 0.0
		if _down("Space") or jumped:
			vy += 1.0
		if _down("ControlLeft") or _down("ControlRight"):
			vy -= 1.0
		velocity = wish * speed * 1.45 + Vector3.UP * vy * speed
	else:
		velocity.x = wish.x * speed
		velocity.z = wish.z * speed
		if not is_on_floor():
			velocity.y -= 28.0 * dt
			velocity.y = maxf(velocity.y, -42.0)
		else:
			if velocity.y < 0.0:
				velocity.y = -0.2
			if jumped:
				velocity.y = 8.4
	move_and_slide()
	var horiz := Vector3(velocity.x, 0.0, velocity.z)
	if horiz.length() > 0.25:
		var face := atan2(-horiz.x, -horiz.z)
		model.rotation.y = lerp_angle(model.rotation.y, face, 1.0 - exp(-14.0 * dt))
	_update_camera(dt, forward)
	_drive_hold()
	if global_position.y < -8.0 and world and world.has_method("respawn_player"):
		world.respawn_player()
	_publish()

func _update_camera(dt: float, _forward: Vector3) -> void:
	var head := global_position + Vector3(0, 1.25, 0)
	var cp := cos(pitch_ang)
	var look := Vector3(-sin(yaw) * cp, sin(pitch_ang), -cos(yaw) * cp)
	if look.length() < 0.001:
		look = Vector3(0, 0, -1)
	look = look.normalized()
	var dist := 5.4
	var desired := head - look * dist
	var space := get_world_3d().direct_space_state
	var q := PhysicsRayQueryParameters3D.create(head, desired)
	q.collision_mask = 1
	q.exclude = [self]
	var hit := space.intersect_ray(q)
	var pos := desired
	if not hit.is_empty():
		pos = hit.position + (head - desired).normalized() * 0.28
	var k := 1.0 - exp(-12.0 * dt)
	camera.global_position = camera.global_position.lerp(pos, k)
	if shake > 0.0:
		shake = maxf(0.0, shake - dt * 1.4)
		camera.global_position += Vector3(randf_range(-1, 1), randf_range(-1, 1), randf_range(-1, 1)) * shake * 0.18
	camera.look_at(head + Vector3(0, 0.1, 0), Vector3.UP)

func _drive_hold() -> void:
	if held == null:
		return
	if not is_instance_valid(held):
		held = null
		return
	var dest := camera.global_position + (-camera.global_basis.z) * hold_dist
	held.linear_velocity = (dest - held.global_position) * 16.0
	held.angular_velocity *= 0.88
	held.sleeping = false

func begin_grab() -> void:
	if held != null:
		return
	if world == null or not world.has_method("camera_ray"):
		return
	var hit: Dictionary = world.camera_ray(28.0)
	if hit.is_empty():
		return
	var b = hit.collider
	if not (b is RigidBody3D):
		return
	if not (b.is_in_group("spawned") or b.is_in_group("crab")):
		return
	held = b
	saved_layer = b.collision_layer
	saved_mask = b.collision_mask
	b.collision_layer = 0
	b.collision_mask = 0
	b.gravity_scale = 0.0
	b.sleeping = false
	b.freeze = false
	if b.is_in_group("crab"):
		b.held = true
	hold_dist = clampf(camera.global_position.distance_to(b.global_position), 2.2, 11.0)

func release_hold(throw: bool) -> void:
	if held == null or not is_instance_valid(held):
		held = null
		return
	held.collision_layer = saved_layer if saved_layer != 0 else (8 if held.is_in_group("crab") else 2)
	held.collision_mask = saved_mask if saved_mask != 0 else (1 | 2 | 4 | 8)
	held.gravity_scale = 1.0 if not held.is_in_group("crab") else 1.35
	if held.is_in_group("crab"):
		held.held = false
	if throw:
		var dir := -camera.global_basis.z
		held.linear_velocity = dir * 18.0 + Vector3(velocity.x, 0, velocity.z) * 0.35
		held.angular_velocity = Vector3(randf_range(-2, 2), randf_range(-2, 2), randf_range(-2, 2))
	held = null

func touch_grab() -> void:
	if held:
		release_hold(false)
	else:
		begin_grab()

func touch_throw() -> void:
	if held:
		release_hold(true)

func _refresh_injected() -> void:
	injected = []
	if not OS.has_feature("web"):
		return
	var raw = JavaScriptBridge.eval("JSON.stringify(window.__godotKeys||[])", true)
	if raw == null:
		return
	var parsed = JSON.parse_string(str(raw))
	if typeof(parsed) == TYPE_ARRAY:
		injected = parsed

func _down(code: String) -> bool:
	if code in injected:
		return true
	match code:
		"KeyW", "ArrowUp":
			return Input.is_physical_key_pressed(KEY_W) or Input.is_physical_key_pressed(KEY_UP)
		"KeyS", "ArrowDown":
			return Input.is_physical_key_pressed(KEY_S) or Input.is_physical_key_pressed(KEY_DOWN)
		"KeyA", "ArrowLeft":
			return Input.is_physical_key_pressed(KEY_A) or Input.is_physical_key_pressed(KEY_LEFT)
		"KeyD", "ArrowRight":
			return Input.is_physical_key_pressed(KEY_D) or Input.is_physical_key_pressed(KEY_RIGHT)
		"ShiftLeft", "ShiftRight":
			return Input.is_physical_key_pressed(KEY_SHIFT)
		"Space":
			return Input.is_physical_key_pressed(KEY_SPACE)
		"ControlLeft", "ControlRight":
			return Input.is_physical_key_pressed(KEY_CTRL)
	return false

func _publish() -> void:
	if not OS.has_feature("web"):
		return
	var spd := Vector2(velocity.x, velocity.z).length()
	JavaScriptBridge.eval("window.__godotYaw=%s;window.__godotSpeed=%s;" % [snappedf(model.rotation.y, 0.0001), snappedf(spd, 0.0001)], true)
