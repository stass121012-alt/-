class_name TideProp
extends RigidBody3D

var kind := "crate"
var fuse := -1.0
var life := -1.0
var cannon_t := 1.1
var spring_cd: Dictionary = {}
var links: Array = []

func setup(k: String) -> void:
	kind = k
	var spec := _spec(k)
	mass = spec.mass
	gravity_scale = spec.gravity
	continuous_cd = spec.ccd
	collision_layer = 2
	collision_mask = 1 | 2 | 4 | 8
	if spec.friction >= 0.0:
		var pm := PhysicsMaterial.new()
		pm.friction = spec.friction
		pm.bounce = spec.bounce
		physics_material_override = pm
	var col := CollisionShape3D.new()
	col.name = "Col"
	col.shape = spec.shape
	add_child(col)
	var mesh := MeshInstance3D.new()
	mesh.name = "Mesh"
	mesh.mesh = spec.mesh
	mesh.material_override = _mat(spec.color, spec.rough, spec.metal, spec.emission)
	add_child(mesh)
	if kind == "bomb":
		var stripe := MeshInstance3D.new()
		var band := CylinderMesh.new()
		band.top_radius = 0.34
		band.bottom_radius = 0.34
		band.height = 0.12
		stripe.mesh = band
		stripe.rotation_degrees = Vector3(90, 0, 0)
		stripe.material_override = _mat(Color("c0392b"), 0.45, 0.1, Color("e07a3d"))
		add_child(stripe)
	if kind == "cannon":
		var barrel := MeshInstance3D.new()
		barrel.name = "Barrel"
		var cyl := CylinderMesh.new()
		cyl.top_radius = 0.16
		cyl.bottom_radius = 0.2
		cyl.height = 1.05
		barrel.mesh = cyl
		barrel.position = Vector3(0, 0.22, -0.15)
		barrel.rotation_degrees = Vector3(-90, 0, 0)
		barrel.material_override = _mat(Color("2c3844"), 0.42, 0.55, Color(0, 0, 0))
		add_child(barrel)
	if kind == "spring":
		var area := Area3D.new()
		area.collision_layer = 0
		area.collision_mask = 2 | 4 | 8
		area.monitorable = false
		var ashape := CollisionShape3D.new()
		var box := BoxShape3D.new()
		box.size = Vector3(1.15, 0.55, 1.15)
		ashape.shape = box
		ashape.position = Vector3(0, 0.45, 0)
		area.add_child(ashape)
		add_child(area)
		area.body_entered.connect(_on_spring)
	if spec.frozen:
		freeze = true
		freeze_mode = RigidBody3D.FREEZE_MODE_STATIC
	if kind == "bomb":
		fuse = 2.7
	contact_monitor = false
	can_sleep = kind != "balloon"

func _spec(k: String) -> Dictionary:
	match k:
		"ball":
			var s := SphereShape3D.new()
			s.radius = 0.38
			var sm := SphereMesh.new()
			sm.radius = 0.38
			sm.height = 0.76
			return _pack(s, sm, 1.1, Color("e24b3b"), 0.35, 0.05, 0.3, 0.82, 1.0, false, true, Color(0, 0, 0))
		"plank":
			var b := BoxShape3D.new()
			b.size = Vector3(2.5, 0.16, 0.62)
			var bm := BoxMesh.new()
			bm.size = b.size
			return _pack(b, bm, 4.5, Color("8d5a32"), 0.82, 0.0, 0.65, 0.05, 1.0, false, false, Color(0, 0, 0))
		"spring":
			var b2 := BoxShape3D.new()
			b2.size = Vector3(1.2, 0.28, 1.2)
			var bm2 := BoxMesh.new()
			bm2.size = b2.size
			return _pack(b2, bm2, 6.0, Color("1e6e58"), 0.55, 0.15, 0.9, 0.02, 1.0, false, false, Color("3dba8b"))
		"bomb":
			var s2 := SphereShape3D.new()
			s2.radius = 0.32
			var sm2 := SphereMesh.new()
			sm2.radius = 0.32
			sm2.height = 0.64
			return _pack(s2, sm2, 2.2, Color("2a2e32"), 0.4, 0.35, 0.55, 0.15, 1.0, false, true, Color("e07a3d"))
		"balloon":
			var s3 := SphereShape3D.new()
			s3.radius = 0.55
			var sm3 := SphereMesh.new()
			sm3.radius = 0.55
			sm3.height = 1.1
			return _pack(s3, sm3, 0.45, Color("e07a3d"), 0.45, 0.0, 0.4, 0.2, 1.0, false, false, Color(0, 0, 0))
		"block":
			var b3 := BoxShape3D.new()
			b3.size = Vector3(1.0, 1.0, 1.0)
			var bm3 := BoxMesh.new()
			bm3.size = b3.size
			return _pack(b3, bm3, 8.0, Color("6e7c86"), 0.78, 0.08, 0.85, 0.0, 1.0, true, false, Color(0, 0, 0))
		"cannon":
			var b4 := BoxShape3D.new()
			b4.size = Vector3(0.72, 0.42, 0.95)
			var bm4 := BoxMesh.new()
			bm4.size = b4.size
			return _pack(b4, bm4, 9.0, Color("3a4654"), 0.4, 0.62, 0.7, 0.02, 1.0, true, false, Color(0, 0, 0))
		"ice":
			var b5 := BoxShape3D.new()
			b5.size = Vector3(2.2, 0.18, 2.2)
			var bm5 := BoxMesh.new()
			bm5.size = b5.size
			return _pack(b5, bm5, 5.0, Color("b7e3ea"), 0.08, 0.12, 0.03, 0.02, 1.0, true, false, Color(0, 0, 0))
		_:
			var b6 := BoxShape3D.new()
			b6.size = Vector3(0.84, 0.84, 0.84)
			var bm6 := BoxMesh.new()
			bm6.size = b6.size
			return _pack(b6, bm6, 3.2, Color("c4844a"), 0.8, 0.0, 0.72, 0.06, 1.0, false, false, Color(0, 0, 0))

func _pack(shape: Shape3D, mesh: Mesh, mass_v: float, color: Color, rough: float, metal: float, friction: float, bounce: float, gravity: float, frozen: bool, ccd: bool, emission: Color) -> Dictionary:
	return {
		"shape": shape,
		"mesh": mesh,
		"mass": mass_v,
		"color": color,
		"rough": rough,
		"metal": metal,
		"friction": friction,
		"bounce": bounce,
		"gravity": gravity,
		"frozen": frozen,
		"ccd": ccd,
		"emission": emission,
	}

func _mat(color: Color, rough: float, metal: float, emission: Color) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = color
	m.roughness = rough
	m.metallic = metal
	if emission.r + emission.g + emission.b > 0.01:
		m.emission_enabled = true
		m.emission = emission
		m.emission_energy_multiplier = 0.45
	return m

func half_height() -> float:
	match kind:
		"ball": return 0.4
		"plank": return 0.12
		"spring": return 0.18
		"bomb": return 0.34
		"balloon": return 0.58
		"block": return 0.52
		"cannon": return 0.28
		"ice": return 0.12
		"crate": return 0.44
		_: return 0.4

func _physics_process(dt: float) -> void:
	if fuse >= 0.0:
		fuse -= dt
		var mesh_node := get_node_or_null("Mesh")
		if mesh_node is MeshInstance3D and mesh_node.material_override is StandardMaterial3D:
			var mat: StandardMaterial3D = mesh_node.material_override
			mat.emission_enabled = true
			mat.emission = Color("e07a3d")
			mat.emission_energy_multiplier = 0.4 + absf(sin(fuse * 18.0)) * 2.2
		if fuse <= 0.0:
			var at := global_position
			var root := get_tree().current_scene
			if root and root.has_method("boom"):
				root.call_deferred("boom", at)
			queue_free()
			return
	if life > 0.0:
		life -= dt
		if life <= 0.0:
			queue_free()
			return
	if kind == "balloon":
		apply_central_force(Vector3.UP * mass * 30.0)
		linear_damp = 1.4
	if kind == "cannon":
		cannon_t -= dt
		if cannon_t <= 0.0:
			cannon_t = 1.75
			var barrel := get_node_or_null("Barrel")
			if barrel is Node3D:
				var from: Vector3 = barrel.global_position + barrel.global_transform.basis.y * 0.7
				var dir: Vector3 = barrel.global_transform.basis.y
				var root2 := get_tree().current_scene
				if root2 and root2.has_method("cannon_shot"):
					root2.call_deferred("cannon_shot", from, dir, self)

func _on_spring(body: Node) -> void:
	if not (body is PhysicsBody3D):
		return
	if body == self:
		return
	var now := Time.get_ticks_msec()
	if int(spring_cd.get(body, 0)) > now:
		return
	spring_cd[body] = now + 450
	if body is RigidBody3D:
		var rb := body as RigidBody3D
		rb.sleeping = false
		rb.apply_central_impulse(Vector3.UP * maxf(rb.mass, 0.4) * 15.0)
	elif body is CharacterBody3D:
		var cb := body as CharacterBody3D
		cb.velocity.y = maxf(cb.velocity.y, 13.5)

func _exit_tree() -> void:
	for j in links:
		if is_instance_valid(j):
			j.queue_free()
