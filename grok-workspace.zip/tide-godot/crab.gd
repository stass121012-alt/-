class_name TideCrab
extends RigidBody3D

var held := false
var goal := Vector3.ZERO
var retarget := 0.0
var walk := 2.15
var home := "free"

func setup(mode: String) -> void:
	home = mode
	mass = 1.15
	gravity_scale = 1.35
	can_sleep = false
	continuous_cd = true
	collision_layer = 8
	collision_mask = 1 | 2 | 4 | 8
	axis_lock_angular_x = true
	axis_lock_angular_z = true
	linear_damp = 0.6
	angular_damp = 2.0
	var col := CollisionShape3D.new()
	var box := BoxShape3D.new()
	box.size = Vector3(0.62, 0.28, 0.46)
	col.shape = box
	add_child(col)
	_part(Vector3(0.62, 0.22, 0.42), Vector3(0, 0.02, 0), Color("e07a3d"), "box")
	_part(Vector3(0.16, 0.16, 0.16), Vector3(0.18, 0.12, -0.2), Color("f0d2b0"), "sphere")
	_part(Vector3(0.16, 0.16, 0.16), Vector3(-0.18, 0.12, -0.2), Color("f0d2b0"), "sphere")
	_part(Vector3(0.22, 0.1, 0.16), Vector3(0.34, 0.02, -0.16), Color("c2412a"), "box")
	_part(Vector3(0.22, 0.1, 0.16), Vector3(-0.34, 0.02, -0.16), Color("c2412a"), "box")
	_part(Vector3(0.08, 0.08, 0.08), Vector3(0.12, 0.16, -0.28), Color("10262e"), "sphere")
	_part(Vector3(0.08, 0.08, 0.08), Vector3(-0.12, 0.16, -0.28), Color("10262e"), "sphere")
	add_to_group("crab")
	add_to_group("spawned")

func _part(size: Vector3, pos: Vector3, color: Color, shape: String) -> void:
	var mi := MeshInstance3D.new()
	if shape == "sphere":
		var sm := SphereMesh.new()
		sm.radius = size.x * 0.5
		sm.height = size.x
		mi.mesh = sm
	else:
		var bm := BoxMesh.new()
		bm.size = size
		mi.mesh = bm
	mi.position = pos
	var m := StandardMaterial3D.new()
	m.albedo_color = color
	m.roughness = 0.62
	mi.material_override = m
	add_child(mi)

func _physics_process(dt: float) -> void:
	if held:
		return
	var flat := Vector2(global_position.x, global_position.z)
	if global_position.y < -4.0 or flat.length() > 58.0:
		if home == "crabs":
			return
		global_position = Vector3(randf_range(-3.0, 3.0), 8.0, randf_range(-3.0, 3.0))
		linear_velocity = Vector3.ZERO
		angular_velocity = Vector3.ZERO
		return
	retarget -= dt
	if retarget <= 0.0 or Vector2(goal.x - global_position.x, goal.z - global_position.z).length() < 1.1:
		var ang := randf() * TAU
		var rad := randf_range(3.0, 16.0)
		if home == "crabs":
			rad = randf_range(14.0, 23.0)
		goal = Vector3(cos(ang) * rad, global_position.y, sin(ang) * rad)
		retarget = randf_range(2.2, 5.0)
	var dir := goal - global_position
	dir.y = 0.0
	if dir.length() > 0.15:
		dir = dir.normalized()
		linear_velocity.x = move_toward(linear_velocity.x, dir.x * walk, dt * 7.0)
		linear_velocity.z = move_toward(linear_velocity.z, dir.z * walk, dt * 7.0)
		rotation.y = lerp_angle(rotation.y, atan2(-dir.x, -dir.z), 1.0 - exp(-8.0 * dt))
