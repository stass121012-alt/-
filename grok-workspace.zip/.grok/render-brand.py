#!/usr/bin/env python3
"""Designed ПРИЛИВ share cards. Imagine quota was exhausted; this is exact-glyph art."""
from PIL import Image, ImageDraw, ImageFilter, ImageFont
import os

INK = (16, 38, 46)
FOAM = (231, 243, 238)
RUST = (224, 122, 61)
BRASS = (226, 177, 90)
KELP = (30, 110, 88)
WOOD = (138, 90, 50)
WOOD_DK = (92, 58, 34)
WOOD_LT = (196, 137, 74)
SAND = (196, 158, 108)
SAND_DK = (122, 92, 62)
SKIN = (232, 186, 142)
WATER_DEEP = (12, 48, 56)
WATER = (22, 110, 112)
WATER_LT = (126, 196, 184)
SKY_TOP = (12, 28, 36)
SKY_MID = (28, 62, 72)
GLOW = (240, 156, 86)

FONT_PATH = "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"
OUT = "/workspace/.grok"


def mix(a, b, t):
    return tuple(int(a[i] + (b[i] - a[i]) * t) for i in range(3))


def vgradient(size, stops):
    w, h = size
    im = Image.new("RGB", size)
    px = im.load()
    stops = sorted(stops)
    for y in range(h):
        t = y / max(1, h - 1)
        for i in range(len(stops) - 1):
            t0, c0 = stops[i]
            t1, c1 = stops[i + 1]
            if t0 <= t <= t1 or i == len(stops) - 2:
                u = 0 if t1 == t0 else (t - t0) / (t1 - t0)
                u = max(0.0, min(1.0, u))
                col = mix(c0, c1, u)
                break
        for x in range(w):
            px[x, y] = col
    return im


def glow(base, cx, cy, radius, color, alpha=180):
    layer = Image.new("RGBA", base.size, (0, 0, 0, 0))
    d = ImageDraw.Draw(layer)
    d.ellipse((cx - radius, cy - radius, cx + radius, cy + radius), fill=color + (alpha,))
    layer = layer.filter(ImageFilter.GaussianBlur(radius // 3))
    return Image.alpha_composite(base.convert("RGBA"), layer)


def polygon(draw, pts, fill, outline=None, width=1):
    draw.polygon(pts, fill=fill, outline=outline)


def iso_crate(draw, x, y, w, h, d):
    # front, side, top — warm wood
    front = [(x, y), (x + w, y), (x + w, y + h), (x, y + h)]
    side = [(x + w, y), (x + w + d, y - d * 0.45), (x + w + d, y + h - d * 0.45), (x + w, y + h)]
    top = [(x, y), (x + d, y - d * 0.45), (x + w + d, y - d * 0.45), (x + w, y)]
    polygon(draw, side, WOOD_DK)
    polygon(draw, front, WOOD)
    polygon(draw, top, WOOD_LT)
    # slats
    draw.line([(x + 6, y + 8), (x + 6, y + h - 8)], fill=WOOD_DK, width=3)
    draw.line([(x + w - 6, y + 8), (x + w - 6, y + h - 8)], fill=WOOD_DK, width=3)
    draw.line([(x + 4, y + h * 0.45), (x + w - 4, y + h * 0.45)], fill=WOOD_LT, width=3)


def salvager(draw, x, y, s=1.0):
    def P(px, py):
        return (x + px * s, y + py * s)
    # legs
    polygon(draw, [P(18, 78), P(34, 78), P(38, 128), P(16, 128)], INK)
    polygon(draw, [P(42, 78), P(58, 78), P(64, 128), P(40, 128)], INK)
    # boots rust
    polygon(draw, [P(12, 122), P(40, 122), P(42, 134), P(10, 134)], RUST)
    polygon(draw, [P(38, 122), P(68, 122), P(70, 134), P(36, 134)], RUST)
    # torso vest
    polygon(draw, [P(14, 36), P(66, 36), P(72, 84), P(10, 84)], FOAM)
    polygon(draw, [P(30, 40), P(50, 40), P(48, 78), P(28, 78)], mix(INK, KELP, 0.35))
    # arms
    polygon(draw, [P(6, 42), P(18, 40), P(12, 86), P(0, 82)], SAND)
    polygon(draw, [P(62, 40), P(76, 44), P(86, 78), P(70, 82)], SAND)
    # hook / rope coil on right hand
    draw.ellipse([P(80, 72), P(96, 88)], outline=BRASS, width=max(2, int(3 * s)))
    # head
    draw.ellipse([P(22, 8), P(60, 46)], fill=SKIN)
    # cap
    polygon(draw, [P(18, 22), P(64, 18), P(66, 30), P(16, 32)], RUST)
    draw.ellipse([P(14, 24), P(70, 36)], fill=RUST)
    # visor brim
    polygon(draw, [P(48, 26), P(78, 30), P(74, 36), P(48, 34)], WOOD_DK)
    # eye
    draw.ellipse([P(40, 28), P(48, 36)], fill=INK)


def cannon(draw, x, y, s=1.0):
    def P(px, py):
        return (x + px * s, y + py * s)
    # wheels
    draw.ellipse([P(8, 36), P(40, 68)], fill=WOOD_DK)
    draw.ellipse([P(78, 32), P(110, 64)], fill=WOOD_DK)
    draw.ellipse([P(16, 44), P(32, 60)], fill=BRASS)
    draw.ellipse([P(86, 40), P(102, 56)], fill=BRASS)
    # carriage
    polygon(draw, [P(18, 28), P(100, 22), P(108, 46), P(14, 52)], WOOD)
    # barrel
    polygon(draw, [P(36, 8), P(130, -6), P(136, 16), P(40, 28)], BRASS)
    polygon(draw, [P(120, -8), P(146, -12), P(150, 14), P(124, 16)], mix(BRASS, FOAM, 0.25))
    draw.ellipse([P(138, -14), P(158, 16)], fill=mix(BRASS, RUST, 0.25))


def crab(draw, x, y, s=1.0, face=1):
    def P(px, py):
        return (x + px * s * face, y + py * s) if False else (x + px * s, y + py * s)
    body = (224, 98, 48)
    claw = (240, 140, 70)
    # legs
    for i, ang in enumerate((-18, -8, 2, 12)):
        draw.line([P(10, 16), P(10 + ang, 30)], fill=body, width=max(2, int(3 * s)))
        draw.line([P(28, 16), P(28 - ang, 30)], fill=body, width=max(2, int(3 * s)))
    draw.ellipse([P(4, 4), P(36, 26)], fill=body)
    # claws
    draw.ellipse([P(-6, 2), P(10, 16)], fill=claw)
    draw.ellipse([P(30, 0), P(46, 14)], fill=claw)
    draw.ellipse([P(12, 10), P(16, 14)], fill=INK)
    draw.ellipse([P(22, 10), P(26, 14)], fill=INK)


def tide_ring(base, cx, cy, rx, ry):
    layer = Image.new("RGBA", base.size, (0, 0, 0, 0))
    d = ImageDraw.Draw(layer)
    box = [cx - rx, cy - ry, cx + rx, cy + ry]
    d.ellipse(box, outline=KELP + (230,), width=7)
    inset = [cx - rx + 8, cy - ry + 4, cx + rx - 8, cy + ry - 4]
    d.ellipse(inset, outline=FOAM + (160,), width=2)
    layer = layer.filter(ImageFilter.GaussianBlur(0.6))
    return Image.alpha_composite(base.convert("RGBA"), layer)


def tracked_width(text, font, tracking, stroke):
    probe = ImageDraw.Draw(Image.new("RGB", (8, 8)))
    total = 0
    for i, ch in enumerate(text):
        b = probe.textbbox((0, 0), ch, font=font, stroke_width=stroke)
        total += b[2] - b[0]
        if i != len(text) - 1:
            total += tracking
    # height from full string
    b = probe.textbbox((0, 0), text, font=font, stroke_width=stroke)
    return total, b[3] - b[1]


def draw_title(base, text, cx, cy, font_size, tracking, stroke):
    font = ImageFont.truetype(FONT_PATH, font_size)
    width, height = tracked_width(text, font, tracking, stroke)
    x = int(cx - width / 2)
    y = int(cy - height / 2)
    layer = Image.new("RGBA", base.size, (0, 0, 0, 0))
    d = ImageDraw.Draw(layer)
    # ink shadow
    cursor = x + 5
    for i, ch in enumerate(text):
        d.text((cursor, y + 7), ch, font=font, fill=INK + (210,), stroke_width=stroke + 2, stroke_fill=INK + (210,))
        b = d.textbbox((0, 0), ch, font=font, stroke_width=stroke)
        cursor += (b[2] - b[0]) + tracking
    # foam stroke + brass fill
    cursor = x
    for i, ch in enumerate(text):
        d.text(
            (cursor, y),
            ch,
            font=font,
            fill=BRASS + (255,),
            stroke_width=stroke,
            stroke_fill=FOAM + (255,),
        )
        b = d.textbbox((0, 0), ch, font=font, stroke_width=stroke)
        cursor += (b[2] - b[0]) + tracking
    right = cursor - (tracking if text else 0)
    # small brass rule under the word, shorter than the word
    rule_y = y + height + 8
    rule_w = int(width * 0.42)
    d.line([(cx - rule_w // 2, rule_y), (cx + rule_w // 2, rule_y)], fill=RUST + (230,), width=4)
    out = Image.alpha_composite(base.convert("RGBA"), layer)
    box = (x, y, right, rule_y + 4)
    return out, box


def scene_og():
    W, H = 1200, 630
    im = vgradient(
        (W, H),
        [
            (0.0, SKY_TOP),
            (0.42, SKY_MID),
            (0.58, mix(GLOW, RUST, 0.35)),
            (0.70, mix(WATER, KELP, 0.4)),
            (1.0, WATER_DEEP),
        ],
    )
    im = glow(im, 860, 300, 220, GLOW, 150)
    im = glow(im, 860, 310, 90, BRASS, 220)
    d = ImageDraw.Draw(im)
    # sun disc
    d.ellipse((820, 262, 900, 342), fill=BRASS)
    d.ellipse((842, 284, 868, 310), fill=mix(BRASS, FOAM, 0.55))
    # distant islets
    polygon(d, [(40, 390), (120, 330), (210, 390)], mix(INK, SKY_MID, 0.45))
    polygon(d, [(180, 392), (250, 348), (320, 392)], mix(INK, KELP, 0.25))
    polygon(d, [(980, 388), (1080, 336), (1160, 388)], mix(INK, SKY_MID, 0.4))
    # water sheen bands
    for i, yy in enumerate(range(430, 620, 18)):
        col = WATER_LT if i % 2 == 0 else mix(WATER, KELP, 0.3)
        d.arc((80, yy, 1120, yy + 36), 200, 340, fill=col, width=2)
    # island mound
    polygon(
        d,
        [(180, 470), (280, 400), (430, 368), (620, 352), (820, 370), (980, 420), (1060, 490), (980, 530), (700, 560), (400, 555), (220, 520)],
        SAND,
    )
    polygon(
        d,
        [(220, 500), (400, 545), (700, 552), (980, 510), (1040, 540), (900, 590), (500, 600), (240, 560)],
        SAND_DK,
    )
    # scrap planks
    polygon(d, [(300, 430), (470, 418), (490, 438), (310, 452)], WOOD)
    polygon(d, [(760, 430), (910, 448), (890, 468), (740, 450)], WOOD_DK)
    # crates
    iso_crate(d, 250, 400, 78, 64, 28)
    iso_crate(d, 300, 360, 62, 50, 22)
    iso_crate(d, 210, 430, 54, 44, 18)
    # salvager + cannon
    salvager(d, 470, 300, 1.15)
    cannon(d, 690, 360, 1.05)
    # buoy
    d.ellipse((930, 430, 970, 470), fill=RUST)
    d.rectangle((946, 468, 954, 500), fill=WOOD_DK)
    crab(d, 390, 500, 1.35)
    crab(d, 860, 490, 1.15)
    im = tide_ring(im, 640, 545, 230, 34)
    im, box = draw_title(im, "ПРИЛИВ", 560, 168, 118, 6, 8)
    return im.convert("RGB"), box


def scene_banner():
    W, H = 1200, 264
    im = vgradient(
        (W, H),
        [
            (0.0, SKY_TOP),
            (0.38, mix(SKY_MID, GLOW, 0.25)),
            (0.55, mix(GLOW, RUST, 0.45)),
            (0.72, mix(WATER, KELP, 0.35)),
            (1.0, WATER_DEEP),
        ],
    )
    im = glow(im, 980, 118, 150, GLOW, 140)
    im = glow(im, 990, 124, 54, BRASS, 210)
    d = ImageDraw.Draw(im)
    d.ellipse((962, 96, 1024, 158), fill=BRASS)
    # horizon islets — right side, scenery may enter the overlay strip
    polygon(d, [(700, 150), (760, 112), (830, 150)], mix(INK, SKY_MID, 0.5))
    polygon(d, [(1040, 148), (1120, 108), (1190, 150)], mix(INK, KELP, 0.3))
    for i, yy in enumerate(range(168, 250, 14)):
        col = WATER_LT if i % 2 == 0 else mix(WATER, KELP, 0.35)
        d.arc((40, yy, 1160, yy + 28), 200, 340, fill=col, width=2)
    polygon(
        d,
        [(360, 176), (480, 150), (700, 142), (900, 156), (1040, 184), (960, 210), (640, 222), (420, 214)],
        SAND,
    )
    polygon(
        d,
        [(420, 196), (700, 210), (980, 196), (1000, 220), (700, 240), (430, 228)],
        SAND_DK,
    )
    iso_crate(d, 430, 150, 46, 36, 16)
    salvager(d, 520, 108, 0.62)
    cannon(d, 640, 148, 0.62)
    crab(d, 780, 188, 0.9)
    crab(d, 900, 180, 0.75)
    im = tide_ring(im, 760, 214, 180, 16)
    # Lockup in the left half, above the midline.
    im, box = draw_title(im, "ПРИЛИВ", 250, 78, 64, 3, 5)
    return im.convert("RGB"), box


def main():
    og, og_box = scene_og()
    ban, ban_box = scene_banner()
    og.save(f"{OUT}/og-render.png")
    ban.save(f"{OUT}/banner-render.png")
    print("og", og.size, "title_box", og_box)
    print("banner", ban.size, "title_box", ban_box)
    # gates
    l, t, r, b = og_box
    assert l > 36 and r < 1164 and t > 16 and b < 600, og_box
    assert 500 < (r - l) < 900, (r - l)
    bl, bt, br, bb = ban_box
    assert br < 600, ban_box  # right half clear of title
    assert bb < 264 * 0.80, ban_box  # not in bottom fifth
    assert bt > 8, ban_box
    assert (bt + bb) / 2 < 132, ban_box  # above midline
    assert bl > 24, ban_box
    print("layout gates ok")


if __name__ == "__main__":
    main()
